//
//  AssignmentOneApp.swift
//  AssignmentOne
//
//  Created by jennifer-wei lin on 16/3/2023.
//

import SwiftUI

@main
struct AssignmentOneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
