Assignment 1

First Milestone

In the first milestone I learned about structs, variables, foreach loops, system images and navigationview

I have implemented these concepts to create a static list of 4 grocery items with a title and some ticked and some not ticked. 

First milestone video link
